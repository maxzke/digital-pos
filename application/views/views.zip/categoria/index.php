<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="page-header">
                <h4 class="page-title">Listado de Categorias de Productos</h4>
                <ul class="breadcrumbs">
                    <li class="nav-home">
                        <a href="<?php echo base_url('producto'); ?>">
                            <i class="flaticon-home"></i>
                            Volver a Productos
                        </a>
                    </li>
                </ul>
            </div>
            <div class="row">
			<!-- CONTENIDO -->
				<div class="col-md-12">
                    <div class="pull-right">
                        <a href="<?php echo site_url('categoria/add'); ?>" class="btn btn-success">Agregar</a> 
                    </div>

                    <table id="content-table" class="table table-sm table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Categoria</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($categorias as $c){ ?>
                            <tr>
                                <td><?php echo $c['id']; ?></td>
                                <td><?php echo $c['nombre']; ?></td>
                                <td>
                                    <a href="<?php echo site_url('categoria/edit/'.$c['id']); ?>" class="btn btn-info btn-xs">Editar</a> 
                                    <a href="<?php echo site_url('categoria/remove/'.$c['id']); ?>" class="btn btn-danger btn-xs">Eliminar</a>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <!-- /CONTENIDO -->
            </div>
        </div>
    </div>    
</div>
