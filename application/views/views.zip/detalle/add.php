<?php echo form_open('detalle/add',array("class"=>"form-horizontal")); ?>

	<div class="form-group">
		<label for="id_venta" class="col-md-4 control-label">Id Venta</label>
		<div class="col-md-8">
			<input type="text" name="id_venta" value="<?php echo $this->input->post('id_venta'); ?>" class="form-control" id="id_venta" />
		</div>
	</div>
	<div class="form-group">
		<label for="producto" class="col-md-4 control-label">Producto</label>
		<div class="col-md-8">
			<input type="text" name="producto" value="<?php echo $this->input->post('producto'); ?>" class="form-control" id="producto" />
		</div>
	</div>
	<div class="form-group">
		<label for="cantidad" class="col-md-4 control-label">Cantidad</label>
		<div class="col-md-8">
			<input type="text" name="cantidad" value="<?php echo $this->input->post('cantidad'); ?>" class="form-control" id="cantidad" />
		</div>
	</div>
	<div class="form-group">
		<label for="precio" class="col-md-4 control-label">Precio</label>
		<div class="col-md-8">
			<input type="text" name="precio" value="<?php echo $this->input->post('precio'); ?>" class="form-control" id="precio" />
		</div>
	</div>
	<div class="form-group">
		<label for="importe" class="col-md-4 control-label">Importe</label>
		<div class="col-md-8">
			<input type="text" name="importe" value="<?php echo $this->input->post('importe'); ?>" class="form-control" id="importe" />
		</div>
	</div>
	<div class="form-group">
		<label for="costo" class="col-md-4 control-label">Costo</label>
		<div class="col-md-8">
			<input type="text" name="costo" value="<?php echo $this->input->post('costo'); ?>" class="form-control" id="costo" />
		</div>
	</div>
	
	<div class="form-group">
		<div class="col-sm-offset-4 col-sm-8">
			<button type="submit" class="btn btn-success">Save</button>
        </div>
	</div>

<?php echo form_close(); ?>