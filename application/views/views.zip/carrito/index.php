<div class="main-panel">
    <div class="content">
        <div class="page-inner">            
            <div class="row">
				<!-- CONTENIDO -->
				<!-- CONTENIDO CARRITO      -->
                <!-- COL-5 CARRITO -->
                <div class="col-sm-12 col-md-5">
                    <div class="card py-2 px-4">
                        <div class="row">
                            <div class="col-md-5 text-center text-dark bg-secondary py-1">
                                Producto
                            </div>
                            <div class="col-md-3 text-center text-dark bg-secondary py-1">
                                Cant
                            </div>
                            <div class="col-md-2 text-dark bg-secondary py-1">
                                Precio
                            </div>
                            <div class="col-md-2 text-dark bg-secondary py-1">
                                Total
                            </div>
                            <div class="col-md-12 pt-2 Carrito" id="Carrito">
                                <!-- cart -->
                                <div id="cart">
                                    <!-- AQUI SE CARGARAN LOS ARTICULOS DINAMICAMENTE -->	                                    	  							
                                </div>
                            </div>
                        </div>
                                            
                        <div class="row mt-2">
                            <!-- TOTAL -->
                            <!-- <div class="col-sm-12 col-md-8 text-center text-sm-center text-md-right">
                                <span class="text-dark h2">Total</span>                
                            </div>
                            <div class="col-sm-12 col-md-4 text-center text-sm-center text-md-right">
                                <span class="text-dark h2 total-cart-cost mr-4"></span>
                            </div> -->
                            <!-- CLIENTE --> 
                            <!-- <div class="col-md-12 mt-2">
                                <div class="btn-group btn-block" role="group" aria-label="seg group">
                                    <a href="<?php //echo base_url('Clientes');?>" 
                                        role="button" 
                                        class="btn btn-block btn-primary lblCliente">cliente
                                    </a>
                                </div>
                            </div>            -->
                            <!-- PAGAR -->
                            <!-- <div class="col-md-2 mt-1">
                                <div class="btn-group btn-block" role="group" aria-label="seg group">
                                    <button type="button" class="btn btn-danger limpiar_carrito">
                                        <i class="far fa-trash-alt fa-2x"></i><br>vaciar
                                    </button>
                                </div>
                            </div> -->
                            <div class="col-md-12 mt-1">
                                <div class="btn-group btn-block" role="group" aria-label="seg group">
                                    <a href="<?php echo ($auth_level == 9) ? base_url('Cobrar/payment/'.$orderMesa['id']) : "#" ?>" role="button" class="btn btn-block btn-success">
                                        <!-- <i class="fas fa-dollar-sign fa-2x"> -->
                                        <h2 id="totalCarrito" class="ml-2 total-cart-cost mr-4"></h2>                                        
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- /COL-5 CARRITO -->
                <!-- COL-7 PRODUCTOS -->
                <div class="col-md-7">
                    <!-- TAB-CARRITO******************************************************************* -->
                    <div class="card px-0 mx-0">
                        <div class="card-header py-0 px-0 bg-secondary">
                            <ul class="nav nav-pills nav-success nav-pills-no-bd nav-pills-icons justify-content-center" id="pills-tab-with-icon" role="tablist">
                                <!-- FLOOR -->
                                <?php foreach($categorias as $s){ ?>
                                    <li class="nav-item submenu">
                                        <a class="nav-link text-capitalize" id="pills-tab-icon-<?php echo $s['id']; ?>" data-toggle="pill" href="#pills-home-icon-<?php echo $s['id']; ?>" role="tab" aria-controls="pills-home-icon" aria-selected="false">                            
                                            <?php echo $s['nombre']; ?>
                                        </a>
                                    </li>
                                <?php } ?>
                                <!-- /FLOOR -->
                            </ul>                    
                        </div>
                        <div class="card-body bg-secondary tab-content productsCarrito px-0" id="pills-with-icon-tabContent">
                            <?php foreach($categorias as $s){ ?>
                                <div class="tab-pane fade" id="pills-home-icon-<?php echo $s['id']; ?>" 
                                role="tabpanel" aria-labelledby="pills-home-tab-icon">
                                        <?php foreach($productos as $p): ?>
                                            <?php if ($s['id'] == $p['id_categoria'] and $p['stock'] > 0){ ?>
                                                <figure class="figure bg-white px-1 sc-add-to-cart"
                                                data-name="<?php echo $p['nombre']; ?>" 
                                                data-price="<?php echo $p['precio']; ?>" 
                                                data-quantity="1"
                                                data-categoria="<?php echo $s['nombre']; ?>"
                                                data-mesa="<?php echo $orderMesa['nombre'] ?>">
                                                <span class="badge badge-primary">
                                                    <?php 
                                                        echo "$ ".number_format($p['precio'],2, ',', ' ');
                                                    ?>
                                                </span>
                                                <img src="<?php echo $p['imagen']; ?>" 
                                                class="figure-img img-fluid rounded pt-1 pb-0 mb-0" 
                                                width="90px"
                                                height="80px">
                                                <figcaption class="figure-caption text-center text-capitalize px-0 py-0 mt-0" style="width:105px;font-size:11px">
                                                    <?php echo $p['nombre']; 
                                                    $str = strlen($p['nombre']);
                                                    if ($str < 20) {
                                                        echo "<br><br>";
                                                    }else{
                                                        echo "<br>";
                                                    }
                                                    ?>
                                                </figcaption>
                                            </figure>&nbsp; &nbsp;
                                                <?php }                           
                                        endforeach; ?>
                                </div>
                            <?php } ?>

                            
                        </div>
                    </div>
                    <!-- /TAB-CARRITO******************************************************************* -->
                </div><!-- /COL-7 PRODUCTOS -->
                <!-- /CONTENIDO CARRITO      -->
            	<!-- /CONTENIDO -->
            </div>
        </div>
    </div>
</div>