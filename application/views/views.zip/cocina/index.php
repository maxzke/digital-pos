<?php
$recarga = "Refresh: 60; URL='".base_url('cocina')."'";
header($recarga);
?>
<div class="main-panel">
    <div class="content">
        <div class="page-inner">            
            <div class="row">
				<!-- CONTENIDO -->
                <div class="col-12 col-sm-12 col-md-4 col-lg-4">
                <span class="text-white">
                <?php //print_r($orden); ?>
                </span>
                    <ul class="list-group" style="font-size:14px;">
                        <?php 
                            foreach ($orden as $key): 
                                switch ($key['status']) {
                                    case '1':
                                        ?>
                                        <a class="nav-link" href="<?php echo base_url('cocina/status/'.$key['id']); ?>">
                                        <li class="list-group-item text-uppercase text-dark">
                                            <?php echo "MESA: ". $key['mesa']." - ". $key['producto'] ?>
                                        </li>
                                        </a>
                                        <?php
                                        break;
                                    case '2':
                                        ?>
                                        <a class="nav-link" href="<?php echo base_url('cocina/status/'.$key['id']); ?>">
                                        <li class="list-group-item text-uppercase text-dark">
                                            <?php echo "MESA: ". $key['mesa']." - ". $key['producto'] ?>
                                            <span class="badge badge-warning" style="font-size:15px;">PREPARANDO</span>
                                        </li>
                                        </a>
                                        <?php
                                        break;
                                    case '3':
                                        ?>
                                        <a class="nav-link" href="<?php echo base_url('cocina/status/'.$key['id']); ?>">
                                        <li class="list-group-item text-uppercase text-dark">
                                            <?php echo "MESA: ". $key['mesa']." - ". $key['producto'] ?>
                                            <span class="badge badge-success" style="font-size:15px;">LISTO</span>
                                        </li>
                                        </a>
                                        <?php
                                        break;
                                    case '4':
                                        ?>
                                        <a class="nav-link" href="<?php echo base_url('cocina/status/'.$key['id']); ?>">
                                        <li class="list-group-item text-uppercase text-dark">
                                            <?php echo "MESA: ". $key['mesa']." - ". $key['producto'] ?>
                                            <span class="badge badge-success" style="font-size:15px;">ENTREGADO</span>
                                        </li>
                                        </a>
                                        <?php
                                        break;
                                    
                                    default:
                                        # code...
                                        break;
                                }
                        ?>
                            
                        <?php endforeach; ?>
                        
                    </ul>
                    <!-- <ul class="nav nav-pills nav-secondary nav-pills-no-bd nav-sm" id="pills-tab" role="tablist">
                        <li class="nav-item submenu">
                            <a class="nav-link" id="pills-today" data-toggle="pill" href="#pills-today" role="tab" aria-selected="false">Today</a>
                        </li>
                        <li class="nav-item submenu">
                            <a class="nav-link active show" id="pills-month" data-toggle="pill" href="#pills-month" role="tab" aria-selected="true">Month</a>
                        </li>
                        <li class="nav-item submenu">
                            <a class="nav-link" id="pills-week" data-toggle="pill" href="#pills-week" role="tab" aria-selected="false">Week</a>
                        </li>
                        <li class="nav-item submenu">
                            <a class="nav-link active show" id="pills-month" data-toggle="pill" href="#pills-month" role="tab" aria-selected="true">Month</a>
                        </li>
                    </ul> -->
                </div>
            	<!-- /CONTENIDO -->
            </div>
        </div>
    </div>
</div>