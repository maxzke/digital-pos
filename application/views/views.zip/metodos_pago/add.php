<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="page-header">
                <h4 class="page-title">Agregar Nuevo Método de Pago</h4>
                <ul class="breadcrumbs">
                    <li class="nav-home">
                        <a href="<?php echo base_url('metodos-pagos'); ?>">
                            <i class="flaticon-home"></i> Volver
                        </a>
                    </li>
                </ul>
            </div>
            <div class="row">
				<div class="col-md-12">
				<!-- CONTENIDO -->
					<?php echo form_open('metodos_pago/add',array("class"=>"form-horizontal")); ?>

						<div class="form-group">
							<label for="metodo" class="col-md-4 control-label"><span class="text-danger">*</span>Metodo</label>
							<div class="col-md-8">
								<input type="text" name="metodo" value="<?php echo $this->input->post('metodo'); ?>" class="form-control" id="metodo" />
								<span class="text-danger"><?php echo form_error('metodo');?></span>
							</div>
						</div>

						<div class="form-group">
							<div class="col-sm-offset-4 col-sm-8">
								<button type="submit" class="btn btn-success">Guardar</button>
							</div>
						</div>

					<?php echo form_close(); ?>
            	<!-- /CONTENIDO -->
				</div>
            </div>
        </div>
    </div>
</div>