<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="page-header">
                <h4 class="page-title">Métodos de Pagos Aceptados</h4>
            </div>
            <div class="row">
				<div class="col-md-12">
				<!-- CONTENIDO -->
					<div class="pull-right">
						<a href="<?php echo site_url('metodos_pago/add'); ?>" class="btn btn-success">Agregar</a> 
					</div>

					<table class="table table-striped table-bordered">
						<tr>
							<th>ID</th>
							<th>Metodo</th>
							<th>Actions</th>
						</tr>
						<?php foreach($metodos_pago as $m){ ?>
						<tr>
							<td><?php echo $m['id']; ?></td>
							<td><?php echo $m['metodo']; ?></td>
							<td>
								<a href="<?php echo site_url('metodos_pago/edit/'.$m['id']); ?>" class="btn btn-info btn-xs">Editar</a> 
								<a href="<?php echo site_url('metodos_pago/remove/'.$m['id']); ?>" class="btn btn-danger btn-xs">Eliminar</a>
							</td>
						</tr>
						<?php } ?>
					</table>

            	<!-- /CONTENIDO -->
				</div>
            </div>
        </div>
    </div>
</div>