<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="page-header">
                <h4 class="page-title">Editar Producto</h4>
                <ul class="breadcrumbs">
                    <li class="nav-home">
                        <a href="<?php echo base_url('producto'); ?>">
                            <i class="flaticon-home"></i> Volver
                        </a>
                    </li>
                </ul>
            </div>
            <div class="row">
				<div class="col-md-12">
				<!-- CONTENIDO -->
					
					<?php echo form_open('producto/edit/'.$producto['id'],array("class"=>"form-horizontal")); ?>

						<div class="form-group">
							<label for="inventariable" class="col-md-4 control-label">Inventariable</label>
							<div class="col-md-8">
								<input type="checkbox" name="inventariable" value="1" <?php echo ($producto['inventariable']==1 ? 'checked="checked"' : ''); ?> id='inventariable' />
							</div>
						</div>
						<div class="form-group">
							<label for="id_categoria" class="col-md-4 control-label"><span class="text-danger">*</span>Categoria</label>
							<div class="col-md-8">
								<select name="id_categoria" class="form-control">
									<option value="">select categoria</option>
									<?php 
									foreach($all_categorias as $categoria)
									{
										$selected = ($categoria['id'] == $producto['id_categoria']) ? ' selected="selected"' : "";

										echo '<option value="'.$categoria['id'].'" '.$selected.'>'.$categoria['nombre'].'</option>';
									} 
									?>
								</select>
								<span class="text-danger"><?php echo form_error('id_categoria');?></span>
							</div>
						</div>
						<div class="form-group">
							<label for="stock_minimo" class="col-md-4 control-label">Stock Minimo</label>
							<div class="col-md-8">
								<input type="text" name="stock_minimo" value="<?php echo ($this->input->post('stock_minimo') ? $this->input->post('stock_minimo') : $producto['stock_minimo']); ?>" class="form-control" id="stock_minimo" />
							</div>
						</div>
						<div class="form-group">
							<label for="nombre" class="col-md-4 control-label"><span class="text-danger">*</span>Nombre</label>
							<div class="col-md-8">
								<input type="text" name="nombre" value="<?php echo ($this->input->post('nombre') ? $this->input->post('nombre') : $producto['nombre']); ?>" class="form-control" id="nombre" />
								<span class="text-danger"><?php echo form_error('nombre');?></span>
							</div>
						</div>
						<div class="form-group">
							<label for="precio" class="col-md-4 control-label"><span class="text-danger">*</span>Precio</label>
							<div class="col-md-8">
								<input type="text" name="precio" value="<?php echo ($this->input->post('precio') ? $this->input->post('precio') : $producto['precio']); ?>" class="form-control" id="precio" />
								<span class="text-danger"><?php echo form_error('precio');?></span>
							</div>
						</div>
						<div class="form-group">
							<label for="costo" class="col-md-4 control-label">Costo</label>
							<div class="col-md-8">
								<input type="text" name="costo" value="<?php echo ($this->input->post('costo') ? $this->input->post('costo') : $producto['costo']); ?>" class="form-control" id="costo" />
								<span class="text-danger"><?php echo form_error('costo');?></span>
							</div>
						</div>
						<div class="form-group">
							<label for="imagen" class="col-md-4 control-label">Imagen</label>
							<div class="col-md-8">
								<input readonly type="text" name="imagen" value="<?php echo ($this->input->post('imagen') ? $this->input->post('imagen') : $producto['imagen']); ?>" class="form-control" id="imagen" />
							</div>
						</div>
						<div class="form-group">
							<label for="stock" class="col-md-4 control-label">Stock</label>
							<div class="col-md-8">
								<input type="text" name="stock" value="<?php echo ($this->input->post('stock') ? $this->input->post('stock') : $producto['stock']); ?>" class="form-control" id="stock" />
								<span class="text-danger"><?php echo form_error('stock');?></span>
							</div>
						</div>

						<div class="form-group">
							<div class="col-sm-offset-4 col-sm-8">
								<button type="submit" class="btn btn-success">Save</button>
							</div>
						</div>

					<?php echo form_close(); ?>
            	<!-- /CONTENIDO -->
				</div>
            </div>
        </div>
    </div>
</div>