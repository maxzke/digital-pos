<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="page-header">
                <h4 class="page-title">Listado de Productos Disponibles</h4>
				<a href="<?php echo base_url('categoria'); ?>" role="button" class="btn btn-info btn-sm ml-2">Agregar Categoria</a>&nbsp;&nbsp;
				<?php if ($this->session->flashdata('item')) { ?>
					<div class="alert alert-success alert-dismissible fade show" role="alert">
					<strong><?php echo $this->session->flashdata('item'); ?>!</strong> Abastecido correctamente
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					</div>
				<?php } ?>
            </div>
            <div class="row">
				<div class="col-md-12">
				<!-- CONTENIDO -->
					<div class="pull-right">
						<a href="<?php echo site_url('producto/add'); ?>" class="btn btn-success">Agregar</a> 
					</div>

					<table id="productos-table" class="table table-sm table-striped table-bordered">
                        <thead>
							<tr>
								<!-- <th>ID</th> -->
								<!-- <th>Inventariable</th> -->
								<th>Categoria</th>
								<th>Producto</th>
								<th>Existencias</th>
								<th>Alerta Minimo</th>
								<th>Precio</th>
								<!-- <th>Costo</th> -->
								<th>Imagen</th>
								<th>Abastecer</th>
								<th>Actions</th>
							</tr>
						</thead>
							<tbody>
							<?php foreach($productos as $p){ ?>
							<tr>
								<!-- <td><?php //echo $p['id']; ?></td> -->
								<!-- <td><?php //echo ($p['inventariable']) ? "Si" : "No"; ?></td> -->
								<td>
									<?php foreach($categorias as $c){
										if ($c['id'] == $p['id_categoria'] ) {
											echo $c['nombre']; 
										}
									}?>
								</td>
								<td><?php echo $p['nombre']; ?></td>
								<td><?php echo $p['stock']; ?></td>
								<td><?php echo $p['stock_minimo']; ?></td>
								<td><?php echo $p['precio']; ?></td>
								<!-- <td><?php //echo $p['costo']; ?></td> -->
								<td>
									<img src="<?php echo $p['imagen']; ?>" class="img-fluid" alt="<?php echo $p['nombre']; ?>" width="50px">
								</td>
								<td>
									<form action="<?php echo base_url('producto/abastecer'); ?>" method="post">
										<div class="input-group">
											<input type="hidden" name="id" value="<?php echo $p['id'] ?>">
											<input name="cantidad" type="text" class="form-control form-control-sm" placeholder="cantidad" aria-label="Recipient's username" aria-describedby="button-addon2">
											<div class="input-group-append">
												<button class="btn btn-sm btn-outline-success" type="submit">Guardar</button>
											</div>
										</div>
									</form>
								</td>
								<td>
									<a href="<?php echo site_url('producto/edit/'.$p['id']); ?>" class="btn btn-info btn-xs">Editar</a> 
									<a href="<?php echo site_url('producto/remove/'.$p['id']); ?>" class="btn btn-danger btn-xs">Eliminar</a>
								</td>
							</tr>
							<?php } ?>
						</tbody>
					</table>

            	<!-- /CONTENIDO -->
				</div>
            </div>
        </div>
    </div>
</div>