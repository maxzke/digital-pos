<div class="page-inner">
    <div class="row">
        <div class="col-md-12">
            <div class="card mt-5">
                <div class="card-body py-0 fondoMesas">
                    <ul class="nav nav-pills nav-success  nav-pills-no-bd nav-pills-icons justify-content-center" id="pills-tab-with-icon" role="tablist">
                        <!-- FLOOR -->
                        <?php $cont = 0; foreach($seccion as $s): ?>
                            <li class="nav-item submenu">
                                <a class="nav-link text-uppercase text-white <?php echo ($cont==0) ? "active show" : "" ; ?>" id="pills-tab-icon-<?php echo $s['id']; ?>" data-toggle="pill" href="#pills-home-icon-<?php echo $s['id']; ?>" role="tab" aria-controls="pills-home-icon" aria-selected="false">                            
                                    <?php echo $s['nombre']; ?>
                                </a>
                            </li>
                        <?php $cont++; 
                        endforeach; ?>
                        <!-- /FLOOR -->
                    </ul>                    
                </div>
                <div class="tab-content fondoMesas" id="pills-with-icon-tabContent">
                    <?php $cont=0; foreach($seccion as $s){ ?>
                        <div class="tab-pane fade <?php echo ($cont==0) ? "active show" : "" ; $cont++;?>" id="pills-home-icon-<?php echo $s['id']; ?>" role="tabpanel" aria-labelledby="pills-home-tab-icon">
                            <div style="height:450px; width:1220px;" class="tablero">
                                <?php foreach($mesas as $m): 
                                    $verde = FALSE;
                                    ?>
                                    <?php foreach($mesa_ocupada as $m_o){
                                        //$c longitud de carrito
                                        //si carrito vacio = [] = 2
                                        $c = strlen($m_o['carrito']);
                                        if ($m_o['id_mesa'] == $m['id'] and $c>2) {
                                            $verde = TRUE;
                                        }
                                    } ?>
                                    <?php if ($s['id'] == $m['seccion']): ?>
                                        <?php if($m['cuadrara'] == 1): ?>
                                            <a href="<?php echo base_url('carrito/order/'.$m['id']); ?>">
                                                <div id="it-<?php echo $m['id']; ?>" 
                                                    style="position:absolute;
                                                        top:<?php echo $m['arriba']; ?>px;
                                                        left:<?php echo $m['izquierda']; ?>px;
                                                        width:<?php echo $m['ancho']; ?>px;
                                                        height:<?php echo $m['alto']; ?>px;" 
                                                        class="mesa item ui-widget-content
                                                        <?php echo ($verde) ? "bg-success" : "" ?>">          
                                                    <span style="position:relative;top:10px;left:10px;">
                                                        <strong>
                                                        <!-- NOMBRE DE LA MESA -->
                                                        <?php 
                                                            if ($m['alias'] == "") {                                                                 
                                                                echo $m['nombre']; 
                                                            }else{
                                                                $name_con_salto = str_replace(" ", "<br>",$m['alias']);
                                                                echo $name_con_salto;
                                                            }                                                            
                                                            ?>
                                                        </strong>
                                                    </span>
                                                </div> 
                                            </a>
                                        <?php 
                                        endif; 
                                        if($m['cuadrara'] == 0): ?>
                                                <a href="<?php echo base_url('carrito/order/'.$m['id']); ?>">
                                                    <div id="it-<?php echo $m['id']; ?>" 
                                                        style="position:absolute;
                                                            top:<?php echo $m['arriba']; ?>px;
                                                            left:<?php echo $m['izquierda']; ?>px;
                                                            width:<?php echo $m['ancho']; ?>px;
                                                            height:<?php echo $m['alto']; ?>px;" 
                                                            class="redonda item ui-widget-content
                                                        <?php echo ($verde) ? "bg-success" : "" ?>">          
                                                        <span style="position:relative;top:10px;left:10px;">
                                                            <strong>
                                                            <!-- NOMBRE DE LA MESA -->
                                                            <?php 
                                                            if ($m['alias'] == "") {                                                                 
                                                                echo $m['nombre']; 
                                                            }else{
                                                                $name_con_salto = str_replace(" ", "<br>",$m['alias']);
                                                                echo $name_con_salto;
                                                            }                                                            
                                                            ?>
                                                            </strong>
                                                        </span>
                                                    </div> 
                                                </a>
                                    <?php 
                                        endif;
                                        if($m['cuadrara'] == 3): ?>
                                            <!-- barra sin pedido solo dibujo -->
                                                <div id="it-<?php echo $m['id']; ?>" 
                                                    style="position:absolute;
                                                        background-color:#fff291;
                                                        border-color:#fff291;
                                                        top:<?php echo $m['arriba']; ?>px;
                                                        left:<?php echo $m['izquierda']; ?>px;
                                                        width:<?php echo $m['ancho']; ?>px;
                                                        height:<?php echo $m['alto']; ?>px;" 
                                                        class="cuadrada item ui-widget-content">          
                                                    <span style="position:relative;top:10px;left:10px;">
                                                        <strong>
                                                        <!-- NOMBRE DE LA MESA -->
                                                        <?php 
                                                        $name_con_salto = str_replace(" ", "<br>",$m['nombre']);
                                                        echo $name_con_salto; 
                                                        ?>
                                                        </strong>
                                                    </span>
                                                </div> 
                                            <!-- /barra sin pedido solo dibujo -->
                                <?php 
                                    endif;

                                endif; ?>                           
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php } ?>

                    
                </div>
            </div>
        </div>        
    </div>
</div>