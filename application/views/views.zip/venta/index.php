<div class="pull-right">
	<a href="<?php echo site_url('venta/add'); ?>" class="btn btn-success">Add</a> 
</div>

<table class="table table-striped table-bordered">
    <tr>
		<th>ID</th>
		<th>Pagada</th>
		<th>Cerrada</th>
		<th>Id Cliente</th>
		<th>Id Usuario</th>
		<th>Id Mesa</th>
		<th>Fecha</th>
		<th>Actions</th>
    </tr>
	<?php foreach($ventas as $v){ ?>
    <tr>
		<td><?php echo $v['id']; ?></td>
		<td><?php echo $v['pagada']; ?></td>
		<td><?php echo $v['cerrada']; ?></td>
		<td><?php echo $v['id_cliente']; ?></td>
		<td><?php echo $v['id_usuario']; ?></td>
		<td><?php echo $v['id_mesa']; ?></td>
		<td><?php echo $v['fecha']; ?></td>
		<td>
            <a href="<?php echo site_url('venta/edit/'.$v['id']); ?>" class="btn btn-info btn-xs">Edit</a> 
            <a href="<?php echo site_url('venta/remove/'.$v['id']); ?>" class="btn btn-danger btn-xs">Delete</a>
        </td>
    </tr>
	<?php } ?>
</table>
