<?php echo form_open('venta/add',array("class"=>"form-horizontal")); ?>

	<div class="form-group">
		<label for="pagada" class="col-md-4 control-label">Pagada</label>
		<div class="col-md-8">
			<input type="checkbox" name="pagada" value="1" id="pagada" />
		</div>
	</div>
	<div class="form-group">
		<label for="cerrada" class="col-md-4 control-label">Cerrada</label>
		<div class="col-md-8">
			<input type="checkbox" name="cerrada" value="1" id="cerrada" />
		</div>
	</div>
	<div class="form-group">
		<label for="id_cliente" class="col-md-4 control-label">Id Cliente</label>
		<div class="col-md-8">
			<input type="text" name="id_cliente" value="<?php echo $this->input->post('id_cliente'); ?>" class="form-control" id="id_cliente" />
		</div>
	</div>
	<div class="form-group">
		<label for="id_usuario" class="col-md-4 control-label">Id Usuario</label>
		<div class="col-md-8">
			<input type="text" name="id_usuario" value="<?php echo $this->input->post('id_usuario'); ?>" class="form-control" id="id_usuario" />
		</div>
	</div>
	<div class="form-group">
		<label for="id_mesa" class="col-md-4 control-label">Id Mesa</label>
		<div class="col-md-8">
			<input type="text" name="id_mesa" value="<?php echo $this->input->post('id_mesa'); ?>" class="form-control" id="id_mesa" />
		</div>
	</div>
	<div class="form-group">
		<label for="fecha" class="col-md-4 control-label">Fecha</label>
		<div class="col-md-8">
			<input type="text" name="fecha" value="<?php echo $this->input->post('fecha'); ?>" class="form-control" id="fecha" />
		</div>
	</div>
	
	<div class="form-group">
		<div class="col-sm-offset-4 col-sm-8">
			<button type="submit" class="btn btn-success">Save</button>
        </div>
	</div>

<?php echo form_close(); ?>