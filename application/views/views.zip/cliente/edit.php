<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="page-header">
                <h4 class="page-title">Configurar</h4>
                <ul class="breadcrumbs">
                    <li class="nav-home">
                        <a href="<?php echo base_url('admin'); ?>">
                            <i class="flaticon-home"></i>
                        </a>
                    </li>
                    <li class="separator">
                        <i class="flaticon-right-arrow"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Base</a>
                    </li>
                    <li class="separator">
                        <i class="flaticon-right-arrow"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Panels</a>
                    </li>
                </ul>
            </div>
            <div class="row">
				<div class="col-md-12">
				<!-- CONTENIDO -->
					<?php echo form_open('cliente/edit/'.$cliente['id'],array("class"=>"form-horizontal")); ?>

						<div class="form-group">
							<label for="nombre" class="col-md-4 control-label"><span class="text-danger">*</span>Nombre</label>
							<div class="col-md-8">
								<input type="text" name="nombre" value="<?php echo ($this->input->post('nombre') ? $this->input->post('nombre') : $cliente['nombre']); ?>" class="form-control" id="nombre" />
								<span class="text-danger"><?php echo form_error('nombre');?></span>
							</div>
						</div>
						<div class="form-group">
							<label for="telefono" class="col-md-4 control-label">Telefono</label>
							<div class="col-md-8">
								<input type="text" name="telefono" value="<?php echo ($this->input->post('telefono') ? $this->input->post('telefono') : $cliente['telefono']); ?>" class="form-control" id="telefono" />
								<span class="text-danger"><?php echo form_error('telefono');?></span>
							</div>
						</div>

						<div class="form-group">
							<div class="col-sm-offset-4 col-sm-8">
								<button type="submit" class="btn btn-success">Save</button>
							</div>
						</div>

					<?php echo form_close(); ?>
            	<!-- /CONTENIDO -->
				</div>
            </div>
        </div>
    </div>
</div>