<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="page-header">
                <h4 class="page-title">Configurar</h4>
                <ul class="breadcrumbs">
                    <li class="nav-home">
                        <a href="<?php echo base_url('admin'); ?>">
                            <i class="flaticon-home"></i>
                        </a>
                    </li>
                    <li class="separator">
                        <i class="flaticon-right-arrow"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Base</a>
                    </li>
                    <li class="separator">
                        <i class="flaticon-right-arrow"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Panels</a>
                    </li>
                </ul>
            </div>
            <div class="row">
				<div class="col-md-12">
				<!-- CONTENIDO -->
					<div class="pull-right">
						<a href="<?php echo site_url('cobrar/addcliente/'.$orderMesa['id']); ?>" class="btn btn-success">Add</a> 
					</div>

					<table id="content-table" class="table table-sm table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Telefono</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                            <tbody>
                            <?php foreach($clientes as $c){ ?>
                                <tr>
                                    <td><?php echo $c['id']; ?></td>
                                    <td class="text-capitalize"><?php echo $c['nombre']; ?></td>
                                    <td><?php echo $c['telefono']; ?></td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Basic example">
                                            <button class="btn btn-sm btn-primary" 
                                                data-id="<?php echo $c['id']; ?>" 
                                                data-nombre="<?php echo $c['nombre']; ?>" 
                                                data-mesa="<?php echo $orderMesa['id']; ?>"
                                                onclick="getCliente(this);" 
                                                type="button"
                                                data-toggle="tooltip" 
                                                data-placement="top" 
                                                title="Seleccionar">
                                                <i class="fas fa-user-check fa-lg"></i> 					
                                            </button>
                                            <button 
                                                href="<?php echo site_url('cliente/edit/'.$c['id']); ?>" 
                                                class="btn btn-sm btn-info btn-xs"
                                                data-toggle="tooltip" 
                                                data-placement="top" 
                                                title="Editar">
                                                <i class="fas fa-pencil-alt"></i>
                                            </button> 
                                            <button href="#" 
                                                data-url="<?php echo site_url('cliente/remove/'.$c['id']); ?>" 
                                                class="btn btn-sm btn-danger btn-xs" 		
                                                onClick="confirmar_alert(this);"
                                                data-toggle="tooltip" 
                                                data-placement="top" 
                                                title="Eliminar">
                                                <i class="far fa-trash-alt"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
					</table>
            	<!-- /CONTENIDO -->
				</div>
            </div>
        </div>
    </div>
</div>