<div class="main-panel">
    <div class="content container">
        <div class="page-inner">
            <div class="row">
				<!-- CONTENIDO -->
                <div class="col-md-12 d-flex justify-content-between">
                    <a href="<?php echo base_url('carrito/order/'.$orderMesa['id']); ?>">
                        <button class="btn btn-warning" type="button"><i class="fas fa-angle-double-left fa-lg"></i> Atrás</button>
                    </a>
                    <span class="h1 text-muted">Pagos</span>
                    <button class="btn btn-success" id="btnValidar" onclick="validarPagos();" type="button">Validar <i class="fas fa-angle-double-right fa-lg"></i></button>
                    <input class="form-control" type="hidden" id="userId" value="<?php echo $this->auth_user_id; ?>">
                </div>
                <!-- TICKET -->
                <div class="col-md-4">
                    <div class="row mt-2">
                        <div class="col-md-5 text-center text-dark bg-white py-1">
                            Producto
                        </div>
                        <div class="col-md-3 text-center text-dark bg-white py-1">
                            Cant
                        </div>
                        <div class="col-md-2 text-dark bg-white py-1">
                            Precio
                        </div>
                        <div class="col-md-2 text-dark bg-white py-1">
                            Total
                        </div>
                        <div class="col-md-12 pt-2 Carrito" id="Carrito">
                            <!-- cart -->
                            <div id="cart">
                                <!-- AQUI SE CARGARAN LOS ARTICULOS DINAMICAMENTE -->	                                    	  							
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /TICKET -->
                <div class="col-md-2 text-center mt-2">
                    <!-- FORMAS DE PAGO -->
                    <div class="card mx-auto bg-secondary" style="max-width: 20rem;">
                        <ul class="list-group list-group-flush text-left">
                            <li class="list-group">
                                <?php foreach ($metodos_pago as $key):  ?>
                                    <a id="btnEfectivo" class="text-white list-group-item list-group-item-action btn bg-info text-capitalize" href="#" onclick="return setMetodoPago(<?php echo "'".$key['metodo']."'"; ?>,<?php echo $key['id']; ?>)">
                                    <?php echo $key['metodo']; ?>
                                    </a>
                                <?php endforeach; ?>
                            </li>                
                        </ul>
                    </div>
                    <!-- DATOS CLIENTE -->
                    <div class="card mx-auto mt-2" style="max-width: 20rem;">
                        <ul class="list-group list-group-flush text-left">
                            <li class="list-group">
                                <a class="list-group-item list-group-item-action bgBody text-capitalize lblCliente" 
                                    href="<?php echo 
                                    base_url('cobrar/clientes/'.$orderMesa['id']);?>">
                                </a>
                            </li>
                            <!-- <li class="list-group-item text-capitalize bgBody">
                                <i class="fas fa-map-marker-alt"></i> Calle Guanajuato #8-A
                            </li>
                            <li class="list-group-item bgBody">
                                <i class="fas fa-mobile-alt"></i> 818707118
                            </li>
                        </ul>
                        <ul class="list-group list-group-flush text-left">
                            <li class="list-group-item text-capitalize bgBody">
                                <i class="fas fa-file-signature"> RFC</i> rafd841115pf5
                            </li>
                            <li class="list-group-item text-capitalize bgBody">
                                <i class="fas fa-file-contract"> RS</i> david ramirez flores
                            </li>
                            <li class="list-group-item bgBody">
                                <i class="far fa-envelope"></i> ramzdave@gmail.com
                            </li>-->
                        </ul> 
                    </div>
                </div>
                <div class="col-md-6">
                    <!-- TOTAL A PAGAR -->
                    <div class="row">
                        <div class="col-md-12 text-center" id="totalImporte">
                            <!-- IMPORTE TOTAL CART JS-->
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-12 text-center">
                            <span>Seleccione un método de pago</span>
                            <table id="tableMetodo" class="table table-bordered abonos-table">
                                <thead class="bg-light">
                                    <tr class="table-active">
                                        <th scope="col">Recibido</th>
                                        <th scope="col">Importe</th>
                                        <th scope="col">Método</th>
                                        <th scope="col"></th>
                                    </tr>
                                </thead>
                                <tbody>                            
                                    <!-- INNER HTML JS-->
                                </tbody>
                            </table>
                            <!-- CAMBIO -->
                            <div class="col-md-12 text-center" id="lblCambio">
                                <!-- IMPORTE TOTAL CART JS-->
                            </div>
                        </div>
                    </div>
                </div>
            	<!-- /CONTENIDO -->
            </div>
        </div>
    </div>
</div>

