<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="page-header">
                <h4 class="page-title">Agregar Nuevo Piso ó Sección</h4>
                <ul class="breadcrumbs">
                    <li class="nav-home">
                        <a href="<?php echo base_url('seccion'); ?>">
                            <i class="flaticon-home"></i> Volver
                        </a>
                    </li>
                </ul>
            </div>
            <div class="row">
				<div class="col-md-12">
				<!-- CONTENIDO -->
					<?php echo form_open('seccion/add',array("class"=>"form-horizontal")); ?>

						<div class="form-group">
							<label for="nombre" class="col-md-4 control-label"><span class="text-danger">*</span>Nombre</label>
							<div class="col-md-8">
								<input type="text" name="nombre" value="<?php echo $this->input->post('nombre'); ?>" class="form-control" id="nombre" />
								<span class="text-danger"><?php echo form_error('nombre');?></span>
							</div>
						</div>

						<div class="form-group">
							<div class="col-sm-offset-4 col-sm-8">
								<button type="submit" class="btn btn-success">Guardar</button>
							</div>
						</div>

					<?php echo form_close(); ?>
            	<!-- /CONTENIDO -->
				</div>
            </div>
        </div>
    </div>
</div>