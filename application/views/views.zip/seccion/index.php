<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="page-header">
                <h4 class="page-title">Configurar Pisos ó Secciones</h4>                
            </div>
            <div class="row">
				<div class="col-md-12">
				<!-- CONTENIDO -->
					<div class="pull-right">
						<a href="<?php echo site_url('seccion/add'); ?>" class="btn btn-success">Agregar</a> 
					</div>

					<table id="content-table" class="table table-sm table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Piso / Sección</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                            <tbody>
                            <?php foreach($seccion as $s){ ?>
                            <tr>
                                <td><?php echo $s['id']; ?></td>
                                <td><?php echo $s['nombre']; ?></td>
                                <td>
                                    <a href="<?php echo site_url('seccion/edit/'.$s['id']); ?>" class="btn btn-info btn-xs">Editar</a> 
                                    <a href="<?php echo site_url('seccion/remove/'.$s['id']); ?>" class="btn btn-danger btn-xs">Eliminar</a>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
					</table>
            	<!-- /CONTENIDO -->
				</div>
            </div>
        </div>
    </div>
</div>