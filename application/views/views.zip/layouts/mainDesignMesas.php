<!DOCTYPE html>
<html lang="es">

<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Manhattan</title>
    <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
    <link rel="icon" href="<?php echo base_url(); ?>assets/img/icon.ico" type="image/x-icon" />

    <!-- Fonts and icons -->
    <script src="<?php echo base_url(); ?>assets/js/plugin/webfont/webfont.min.js"></script>
    <script>
        WebFont.load({
            google: {
                "families": ["Lato:300,400,700,900"]
            },
            custom: {
                "families": ["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"],
                urls: ['<?php echo base_url(); ?>assets/css/fonts.min.css']
            },
            active: function() {
                sessionStorage.fonts = true;
            }
        });
    </script>

    <!-- CSS Files -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/atlantis.min.css">

    <!-- CSS Drag -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/jquery-ui.css">
    <style>
      .mesa { cursor: move; }
      /* .mesa h3 { text-align: center; margin: 0; } */
      .redonda {
        cursor: move;        
        border-radius: 200px 200px 200px 200px;
        -moz-border-radius: 200px 200px 200px 200px;
        -webkit-border-radius: 200px 200px 200px 200px;
        border: 0px solid #000000;
      }
      .fondoMesas{
          background-color:#585b5b;
      }
      .tablero{
        background-color:#585b5b;
        border-width: 1px;
        border-style: dashed;
        border-color: red;
      }
    </style>
</head>

<body style="background-color:#585b5b">
    <div class="wrapper">
        <div class="main-header">
            <!-- Logo Header -->
            <div class="logo-header" data-background-color="red">

                <a href="<?php echo base_url(); ?>" class="logo">
                    <img src="<?php echo base_url(); ?>assets/img/logo.png" alt="navbar brand" class="navbar-brand">
                </a>
                <input type="hidden" id="baseurl" value="<?php echo base_url(); ?>">
                <!-- <button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse" data-target="collapse" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon">
						<i class="icon-menu"></i>
					</span>
				</button>
                <button class="topbar-toggler more"><i class="icon-options-vertical"></i></button>
                <div class="nav-toggle">
                    <button class="btn btn-toggle toggle-sidebar">
						<i class="icon-menu"></i>
					</button>
                </div> -->
            </div>
            <!-- End Logo Header -->

            <!-- Navbar Header -->
            <!-- Navbar Header -->
            <nav class="navbar navbar-header navbar-expand-lg" data-background-color="red">

                <div class="container-fluid">
                    <ul class="navbar-nav topbar-nav ml-md-auto align-items-center">
                    
                        <li class="nav-item dropdown hidden-caret">
                            <a class="nav-link text-capitalize" href="#" id="notifDropdown" aria-haspopup="true" aria-expanded="false">                                
                                <strong><?php echo $auth_username; ?></strong>
                            </a>
                        </li>
                        <li class="nav-item dropdown hidden-caret">
                            <a class="dropdown-toggle profile-pic" data-toggle="dropdown" href="#" aria-expanded="false">
                                <div class="avatar-sm">
                                <?php 
                                $img = "";
                                $nivel = $auth_level;
                                switch ($nivel) {
                                    case 1:
                                        $img = "assets/img/user-cocina.png";
                                        break;
                                    case 6:
                                        $img = "assets/img/user-mesero.png";
                                        break;
                                    case 9:
                                        $img = "assets/img/user-admin.png";
                                        break;                                    
                                    default:
                                        # code...
                                        break;
                                }
                                ?>
                                    <img src="<?php echo base_url($img); ?>" alt="..." class="avatar-img">
                                </div>
                            </a>
                            <ul class="dropdown-menu dropdown-user animated fadeIn">
                                <div class="dropdown-user-scroll scrollbar-outer">                                    
                                    <li>
                                        <div class="dropdown-divider"></div>                                        
                                        <a class="dropdown-item text-danger" href="<?php echo base_url('login/logout') ?>">
                                            <strong>Salir</strong>
                                        </a>
                                    </li>
                                </div>
                            </ul>
                        </li>
                        <li class="nav-item dropdown hidden-caret">
                            <a class="nav-link text-uppercase" href="#" id="notifDropdown" aria-haspopup="true" aria-expanded="false">                                
                                <strong><?php echo $auth_role; ?></strong>
                            </a>
                        </li>
                        <?php
                        if ($auth_level ==9): ?>
                            <li class="nav-item dropdown hidden-caret">
                            <a class="nav-link" data-toggle="dropdown" href="#" aria-expanded="false">
                            <i class="flaticon-interface-4"></i>
                            </a>
                            <div class="dropdown-menu quick-actions quick-actions-danger animated fadeIn">
                                <div class="quick-actions-header">
                                    <span class="title mb-1">MENU</span>
                                </div>
                                <div class="quick-actions-scroll scrollbar-outer">
                                    <div class="quick-actions-items">
                                        <div class="row m-0">
                                            <a class="col-6 col-md-4 p-0" 
                                            href="<?php echo base_url('punto-de-venta'); ?>">
                                                <div class="quick-actions-item">
                                                    <i class="flaticon-imac"></i>
                                                    <span class="text">TPV</span>
                                                </div>
                                            </a>
                                            <a class="col-6 col-md-4 p-0" 
                                            href="<?php echo base_url('cocina'); ?>">
                                                <div class="quick-actions-item">
                                                    <i class="flaticon-tea-cup"></i>
                                                    <span class="text">Cocina</span>
                                                </div>
                                            </a>
                                            <a class="col-6 col-md-4 p-0" 
                                            href="<?php echo base_url('creditos'); ?>">
                                                <div class="quick-actions-item">
                                                    <i class="flaticon-coins"></i>
                                                    <span class="text">Creditos</span>
                                                </div>
                                            </a>
                                            <a class="col-6 col-md-4 p-0" 
                                            href="<?php echo base_url('usuarios'); ?>">
                                                <div class="quick-actions-item">
                                                    <i class="flaticon-user-5"></i>
                                                    <span class="text">Usuarios</span>
                                                </div>
                                            </a>
                                            <a class="col-6 col-md-4 p-0" 
                                            href="<?php echo base_url('mesas'); ?>">
                                                <div class="quick-actions-item">
                                                    <i class="flaticon-circle"></i>
                                                    <span class="text">Mesas</span>
                                                </div>
                                            </a>
                                            <!-- <a class="col-6 col-md-4 p-0" 
                                            href="<?php //echo base_url('ajustar-mesas'); ?>">
                                                <div class="quick-actions-item">
                                                    <i class="flaticon-expand"></i>
                                                    <span class="text">Mesas</span>
                                                </div>
                                            </a> -->
                                            <a class="col-6 col-md-4 p-0" 
                                            href="<?php echo base_url('productos'); ?>">
                                                <div class="quick-actions-item">
                                                    <i class="flaticon-box-1"></i>
                                                    <span class="text">Productos</span>
                                                </div>
                                            </a>
                                            <!-- <a class="col-6 col-md-4 p-0" 
                                            href="<?php //echo base_url('metodos-pagos'); ?>">
                                                <div class="quick-actions-item">
                                                    <i class="flaticon-credit-card-1"></i>
                                                    <span class="text">Pagos</span>
                                                </div>
                                            </a> -->
                                            <!-- <a class="col-6 col-md-4 p-0" 
                                            href="<?php //echo base_url('secciones'); ?>">
                                                <div class="quick-actions-item">
                                                    <i class="flaticon-web"></i>
                                                    <span class="text">Pisos</span>
                                                </div>
                                            </a> -->
                                            <a class="col-6 col-md-4 p-0" 
                                                href="<?php echo base_url('reportes'); ?>">
                                                <div class="quick-actions-item">
                                                    <i class="flaticon-graph-2"></i>
                                                    <span class="text">Reportes</span>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <?php endif;?>
                        
                    </ul>
                </div>
            </nav>
            <!-- End Navbar -->
        </div>

        <!-- Sidebar -->
        <!-- End Sidebar -->
        <!-- Custom template | don't include it in your project! -->
		
            <?php	if(isset($_view) && $_view)
                $this->load->view($_view);
            ?>  		
        <!-- End Custom template -->
    </div><!-- /wrapper -->
    <!--   Core JS Files   -->
    <script src="<?php echo base_url(); ?>assets/js/core/jquery.3.2.1.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/core/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/core/bootstrap.min.js"></script>

    <!-- jQuery UI -->
    <script src="<?php echo base_url(); ?>assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

    <!-- jQuery Scrollbar -->
    <script src="<?php echo base_url(); ?>assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>


    <!-- Chart JS -->
    <script src="<?php echo base_url(); ?>assets/js/plugin/chart.js/chart.min.js"></script>

    <!-- jQuery Sparkline -->
    <script src="<?php echo base_url(); ?>assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

    <!-- Chart Circle -->
    <script src="<?php echo base_url(); ?>assets/js/plugin/chart-circle/circles.min.js"></script>

    <!-- Datatables -->
    <script src="<?php echo base_url(); ?>assets/js/plugin/datatables/datatables.min.js"></script>

    <!-- Bootstrap Notify -->
    <script src="<?php echo base_url(); ?>assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

    <!-- jQuery Vector Maps -->
    <script src="<?php echo base_url(); ?>assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

    <!-- Sweet Alert -->
    <script src="<?php echo base_url(); ?>assets/js/plugin/sweetalert/sweetalert.min.js"></script>

    <!-- Atlantis JS -->
    <script src="<?php echo base_url(); ?>assets/js/atlantis.min.js"></script>

    <script src="<?php echo base_url(); ?>assets/js/draggable.js"></script>
    <!-- ALERTAS COCINA -->
    <script src="<?php echo base_url(); ?>assets/js/alertas_cocina.js"></script>
</body>

</html>