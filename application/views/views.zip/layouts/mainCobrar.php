<!DOCTYPE html>
<html lang="es">

<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Manhattan</title>
    <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
    <link rel="icon" href="<?php echo base_url(); ?>assets/img/icon.ico" type="image/x-icon" />

    <!-- Fonts and icons -->
    <script src="<?php echo base_url(); ?>assets/js/plugin/webfont/webfont.min.js"></script>
    <!-- Carrito -->
    <link type="text/css" rel="stylesheet" href="<?php echo base_url()?>assets/css/simple_Cart.css"/>
    <script>
        WebFont.load({
            google: {
                "families": ["Lato:300,400,700,900"]
            },
            custom: {
                "families": ["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"],
                urls: ['<?php echo base_url(); ?>assets/css/fonts.min.css']
            },
            active: function() {
                sessionStorage.fonts = true;
            }
        });
    </script>

    <!-- CSS Files -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/atlantis.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/alertify.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/semantic.min.css">

    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/notfound.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/jquery-ui.css">
    <style>
      /* .mesa h3 { text-align: center; margin: 0; } */
      .redonda {       
        border-radius: 200px 200px 200px 200px;
        -moz-border-radius: 200px 200px 200px 200px;
        -webkit-border-radius: 200px 200px 200px 200px;
        border: 0px solid #000000;
      }
      .fondoMesas{
          background-color:#585b5b;
      }
      .Carrito {
          /* columna izquierda carrito Cart */
        height: 55vh;
        width: 100%;
        border: none;
        overflow-y: scroll;
        background-color: #fff;
        }
        .productsCarrito{
            /* columna derecha categorias y productos */
            height: 66vh;
            width: 100%;
            border: none;
            overflow-y: scroll;
            background-color: #fff;
        }
        .figure{
            /* agrega curso mano a producto */
            cursor: pointer;
        }
    </style>
</head>

<body style="background-color:#E5E7E7">
    <div class="wrapper">
        <div class="main-header">
        <input type="hidden" id="baseUrl" value="<?php echo base_url(); ?>">
        <input type="hidden" id="actualizar" value="0">
        
            <!-- Logo Header -->
            <div class="logo-header" data-background-color="red">
                <a href="<?php echo base_url(); ?>" class="logo">
                    <img src="<?php echo base_url('assets/img/logo.png'); ?>" alt="navbar brand" class="navbar-brand">
                </a>                
            </div>
            <!-- End Logo Header -->

            <!-- Navbar Header -->
            <nav class="navbar navbar-header navbar-expand-lg" data-background-color="red">

                <div class="container-fluid">

                    <div class="collapse" id="search-nav">
                        <div class="navbar-left text-center">       
                            <a href="<?php echo base_url('carrito/order/'.$orderMesa['id']); ?>">                   
                                <button type="button" class="btn btn-warning" id="mesa" data-idmesa="<?php echo $orderMesa['id']; ?>"
                                data-baseurl="<?php echo base_url(); ?>">
                                <i class="fas fa-chevron-left"></i>
                                <span class="text-dark text-uppercase"> Mesa: <?php echo $orderMesa['nombre']." ".$orderMesa['alias'];; ?>
                                </span>
                                </button>    
                            </a>                     
                        </div>
                    </div>
                    
                    <ul class="navbar-nav topbar-nav ml-md-auto align-items-center">
                        <!-- ----------------------------------- -->
                        <li class="nav-item dropdown hidden-caret submenu">
							<a class="nav-link dropdown-toggle" href="#" id="notifDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<i class="fa fa-bell"></i>
								<span class="notification"><?php echo $alertas['cantidad'] ?></span>
							</a>
							<ul class="dropdown-menu notif-box animated fadeIn" aria-labelledby="notifDropdown">
								<li>
									<div class="dropdown-title">Reabastecer Productos</div>
								</li>
								<li>
									<div class="scroll-wrapper notif-scroll scrollbar-outer" style="position: relative;"><div class="notif-scroll scrollbar-outer scroll-content" 
                                    style="height: auto; 
                                    margin-bottom: 0px; 
                                    margin-right: 0px; 
                                    max-height: 256px;">                                    
										<div class="notif-center"
                                        style="height: 256px;
                                        border: none;
                                        overflow-y: scroll;">
                                            <?php foreach ($alertas['items'] as $key): ?>
                                            <a href="#">
												<div class="notif-icon"> 
                                                    <img src="<?php echo $key['imagen']?>" width="50px"> 
                                                </div>
												<div class="notif-content">
													<span class="block">
                                                    <?php echo $key['nombre'] ?>
													</span>
													<span class="time">Existencias: <?php echo $key['stock'] ?></span> 
												</div>
											</a>
                                            <?php endforeach; ?>
                                            
										</div>
									</div><div class="scroll-element scroll-x"><div class="scroll-element_outer"><div class="scroll-element_size"></div><div class="scroll-element_track"></div><div class="scroll-bar ui-draggable ui-draggable-handle" style="width: 100px;"></div></div></div><div class="scroll-element scroll-y"><div class="scroll-element_outer"><div class="scroll-element_size"></div><div class="scroll-element_track"></div><div class="scroll-bar ui-draggable ui-draggable-handle" style="height: 100px;"></div></div></div></div>
								</li>
							</ul>
						</li>                        
                        <!-- ----------------------------------- -->
                        <li class="nav-item dropdown hidden-caret">
                            <a class="nav-link text-capitalize" href="#" id="notifDropdown" aria-haspopup="true" aria-expanded="false">                                
                                <strong><?php echo $auth_username; ?></strong>
                            </a>
                        </li>
                        <li class="nav-item dropdown hidden-caret">
                            <a class="dropdown-toggle profile-pic" data-toggle="dropdown" href="#" aria-expanded="false">
                                <div class="avatar-sm">
                                <?php 
                                $img = "";
                                $nivel = $auth_level;
                                switch ($nivel) {
                                    case 1:
                                        $img = "assets/img/user-cocina.png";
                                        break;
                                    case 6:
                                        $img = "assets/img/user-mesero.png";
                                        break;
                                    case 9:
                                        $img = "assets/img/user-admin.png";
                                        break;                                    
                                    default:
                                        # code...
                                        break;
                                }
                                ?>
                                    <img src="<?php echo base_url($img); ?>" alt="..." class="avatar-img">
                                </div>
                            </a>
                            <ul class="dropdown-menu dropdown-user animated fadeIn">
                                <div class="dropdown-user-scroll scrollbar-outer">                                    
                                    <li>
                                        <div class="dropdown-divider"></div>                                        
                                        <a class="dropdown-item text-danger" href="<?php echo base_url('login/logout') ?>">
                                            <strong>Salir</strong>
                                        </a>
                                    </li>
                                </div>
                            </ul>
                        </li>
                        <li class="nav-item dropdown hidden-caret">
                            <a class="nav-link text-uppercase" href="#" id="notifDropdown" aria-haspopup="true" aria-expanded="false">                                
                                <strong><?php echo $auth_role; ?></strong>
                            </a>
                        </li>
                        <?php
                        if ($auth_level ==9): ?>
                            <li class="nav-item dropdown hidden-caret">
                            <a class="nav-link" data-toggle="dropdown" href="#" aria-expanded="false">
                            <i class="flaticon-interface-4"></i>
                            </a>
                            <div class="dropdown-menu quick-actions quick-actions-danger animated fadeIn">
                                <div class="quick-actions-header">
                                    <span class="title mb-1">Configurar</span>
                                </div>
                                <div class="quick-actions-scroll scrollbar-outer">
                                    <div class="quick-actions-items">
                                        <div class="row m-0">
                                        <a class="col-6 col-md-4 p-0" 
                                            href="<?php echo base_url('punto-de-venta'); ?>">
                                                <div class="quick-actions-item">
                                                    <i class="flaticon-imac"></i>
                                                    <span class="text">TPV</span>
                                                </div>
                                            </a>
                                            <a class="col-6 col-md-4 p-0" 
                                            href="<?php echo base_url('cocina'); ?>">
                                                <div class="quick-actions-item">
                                                    <i class="flaticon-tea-cup"></i>
                                                    <span class="text">Cocina</span>
                                                </div>
                                            </a>
                                            <a class="col-6 col-md-4 p-0" 
                                            href="<?php echo base_url('creditos'); ?>">
                                                <div class="quick-actions-item">
                                                    <i class="flaticon-coins"></i>
                                                    <span class="text">Creditos</span>
                                                </div>
                                            </a>
                                            <a class="col-6 col-md-4 p-0" 
                                            href="<?php echo base_url('usuarios'); ?>">
                                                <div class="quick-actions-item">
                                                    <i class="flaticon-user-5"></i>
                                                    <span class="text">Usuarios</span>
                                                </div>
                                            </a>
                                            <a class="col-6 col-md-4 p-0" 
                                            href="<?php echo base_url('mesas'); ?>">
                                                <div class="quick-actions-item">
                                                    <i class="flaticon-circle"></i>
                                                    <span class="text">Mesas</span>
                                                </div>
                                            </a>
                                            <!-- <a class="col-6 col-md-4 p-0" 
                                            href="<?php //echo base_url('ajustar-mesas'); ?>">
                                                <div class="quick-actions-item">
                                                    <i class="flaticon-expand"></i>
                                                    <span class="text">Mesas</span>
                                                </div>
                                            </a> -->
                                            <a class="col-6 col-md-4 p-0" 
                                            href="<?php echo base_url('productos'); ?>">
                                                <div class="quick-actions-item">
                                                    <i class="flaticon-box-1"></i>
                                                    <span class="text">Productos</span>
                                                </div>
                                            </a>
                                            <!-- <a class="col-6 col-md-4 p-0" 
                                            href="<?php //echo base_url('metodos-pagos'); ?>">
                                                <div class="quick-actions-item">
                                                    <i class="flaticon-credit-card-1"></i>
                                                    <span class="text">Pagos</span>
                                                </div>
                                            </a> -->
                                            <!-- <a class="col-6 col-md-4 p-0" 
                                            href="<?php //echo base_url('secciones'); ?>">
                                                <div class="quick-actions-item">
                                                    <i class="flaticon-web"></i>
                                                    <span class="text">Pisos</span>
                                                </div>
                                            </a> -->
                                            <a class="col-6 col-md-4 p-0" 
                                                href="<?php echo base_url('reportes'); ?>">
                                                <div class="quick-actions-item">
                                                    <i class="flaticon-graph-2"></i>
                                                    <span class="text">Reportes</span>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <?php endif;?>
                        
                    </ul>
                </div>
            </nav>
            <!-- End Navbar -->
        </div>

        <!-- Sidebar -->
        <!-- End Sidebar -->
        <!-- Custom template | don't include it in your project! -->		
            <?php	if(isset($_view) && $_view)
                $this->load->view($_view);
            ?> 	
        <!-- End Custom template -->
    </div><!-- /wrapper -->
    <!--   Core JS Files   -->
    <script src="<?php echo base_url(); ?>assets/js/core/jquery.3.2.1.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/core/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/core/bootstrap.min.js"></script>

    <!-- jQuery UI -->
    <script src="<?php echo base_url(); ?>assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

    <!-- jQuery Scrollbar -->
    <script src="<?php echo base_url(); ?>assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>


    <!-- Chart JS -->
    <script src="<?php echo base_url(); ?>assets/js/plugin/chart.js/chart.min.js"></script>

    <!-- jQuery Sparkline -->
    <script src="<?php echo base_url(); ?>assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

    <!-- Chart Circle -->
    <script src="<?php echo base_url(); ?>assets/js/plugin/chart-circle/circles.min.js"></script>

    <!-- Datatables -->
    <script src="<?php echo base_url(); ?>assets/js/plugin/datatables/datatables.min.js"></script>

    <!-- Bootstrap Notify -->
    <script src="<?php echo base_url(); ?>assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

    <!-- jQuery Vector Maps -->
    <script src="<?php echo base_url(); ?>assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

    <!-- Sweet Alert -->
    <script src="<?php echo base_url(); ?>assets/js/plugin/sweetalert/sweetalert.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/sweetalert2.all.min.js"></script>

    <!-- Atlantis JS -->
    <script src="<?php echo base_url(); ?>assets/js/atlantis.min.js"></script>
    <!-- carrito -->
    <?php if ($nivel ==9){?>
        <script src="<?php echo base_url()?>assets/js/alertify.min.js"></script>
        <script src="<?php echo base_url()?>assets/js/alertas.js"></script>
        <script src="<?php echo base_url()?>assets/js/jQuery.SimpleCartMeseros.js"></script>
        <script src="<?php echo base_url()?>assets/js/punto-de-venta.js"></script>
    <?php }else{ ?>
        <script src="<?php echo base_url()?>assets/js/jQuery.SimpleCartMeseros.js"></script>
    <?php } ?>
    
    <script src="<?php echo base_url()?>assets/js/tablas.js"></script>
    <script>
        $(document).ready(function () {
            setTimeout("doit();",500)
        });        
        function doit(){
            $('#cart').simpleCart();
        }
        const actualiza = document.getElementById('actualizar');
        
        actualiza.addEventListener('click',actualizaCarrito);
        function actualizaCarrito(){        
            let idmesa = mesa.dataset.idmesa;
            let baseurl = mesa.dataset.baseurl;
            let urlrequest = baseurl+'carrito/getCarrito';
            getCarrito(idmesa,urlrequest);
        }
    </script>
    <!-- ALERTAS COCINA -->
    <script src="<?php echo base_url(); ?>assets/js/alertas_cocina.js"></script>
</body>

</html>