<?php echo form_open('pago/add',array("class"=>"form-horizontal")); ?>

	<div class="form-group">
		<label for="id_venta" class="col-md-4 control-label">Id Venta</label>
		<div class="col-md-8">
			<input type="text" name="id_venta" value="<?php echo $this->input->post('id_venta'); ?>" class="form-control" id="id_venta" />
		</div>
	</div>
	<div class="form-group">
		<label for="id_metodo" class="col-md-4 control-label">Id Metodo</label>
		<div class="col-md-8">
			<input type="text" name="id_metodo" value="<?php echo $this->input->post('id_metodo'); ?>" class="form-control" id="id_metodo" />
		</div>
	</div>
	<div class="form-group">
		<label for="importe" class="col-md-4 control-label">Importe</label>
		<div class="col-md-8">
			<input type="text" name="importe" value="<?php echo $this->input->post('importe'); ?>" class="form-control" id="importe" />
		</div>
	</div>
	<div class="form-group">
		<label for="fecha" class="col-md-4 control-label">Fecha</label>
		<div class="col-md-8">
			<input type="text" name="fecha" value="<?php echo $this->input->post('fecha'); ?>" class="form-control" id="fecha" />
		</div>
	</div>
	
	<div class="form-group">
		<div class="col-sm-offset-4 col-sm-8">
			<button type="submit" class="btn btn-success">Save</button>
        </div>
	</div>

<?php echo form_close(); ?>