<div class="pull-right">
	<a href="<?php echo site_url('pago/add'); ?>" class="btn btn-success">Add</a> 
</div>

<table class="table table-striped table-bordered">
    <tr>
		<th>ID</th>
		<th>Id Venta</th>
		<th>Id Metodo</th>
		<th>Importe</th>
		<th>Fecha</th>
		<th>Actions</th>
    </tr>
	<?php foreach($pagos as $p){ ?>
    <tr>
		<td><?php echo $p['id']; ?></td>
		<td><?php echo $p['id_venta']; ?></td>
		<td><?php echo $p['id_metodo']; ?></td>
		<td><?php echo $p['importe']; ?></td>
		<td><?php echo $p['fecha']; ?></td>
		<td>
            <a href="<?php echo site_url('pago/edit/'.$p['id']); ?>" class="btn btn-info btn-xs">Edit</a> 
            <a href="<?php echo site_url('pago/remove/'.$p['id']); ?>" class="btn btn-danger btn-xs">Delete</a>
        </td>
    </tr>
	<?php } ?>
</table>
