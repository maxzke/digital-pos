<div class="main-panel" style="background-color:#ffffff;">
    <div class="content">
        <div class="page-inner">
            <div class="page-header">
                <h4 class="page-title">Clientes con Creditos</h4>
                <input type="hidden" value="<?php echo base_url(); ?>" id="url_hide">
                <ul class="breadcrumbs">
                    <li class="nav-home">
                        <a href="<?php echo base_url('admin'); ?>" 
                        class="btn btn-success btn-sm" 
                        data-toggle="modal" data-target="#clientesModal">
                        <i class="far fa-user"></i>
                            Seleccionar Cliente
                        </a>
                     </li>
                    <li class="separator">
                        <i class="flaticon-right-arrow"></i>
                    </li>
                    <li class="nav-item">
                        <div id="nombreCliente" class="text-uppercase"></div>
                    </li>
                    <!--<li class="separator">
                        <i class="flaticon-right-arrow"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Panels</a>
                    </li> -->
                </ul>
            </div>
            <div class="row">
                <div id="saldos" class="col-md-2">
                    <!-- CARGA DINAMICAMENTE
                    SALDOS 
                    FECHAS DE VENTAS CON ADEUDO -->
                </div>
                <!-- TICKET -->
                <div class="col-md-5 border-left">
                    <table id="carticket" class="table table-sm table-responsive">                    
                        <thead>
                            <tr>
                            <th scope="col">PRODUCTO</th>
                            <th scope="col">CANT</th>
                            <th scope="col">PRECIO</th>
                            <th scope="col">IMPORTE</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>             
                    <p class="text-muted">Ticket Detalles</p>                                       
                </div><!-- /TICKET -->
                <!-- HISTORIAL ABONOS -->
				<div class="col-md-4 border-left">
                    <table id="abonos" class="table table-sm table-responsive">                    
                        <thead>
                            <tr>
                            <th scope="col">FECHA</th>
                            <th scope="col">IMPORTE</th>
                            <th scope="col">METODO</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                    <p class="text-muted">Historial de Abonos</p>
				</div><!--col-md-5 -->
                <!-- /HISTORIAL ABONOS -->
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="clientesModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="exampleModalLabel">CLIENTES CON ADEUDO</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!-- CONTENIDO -->
        <table id="content-clientes" class="table table-sm table-striped table-bordered">
            <thead>
                <tr>
                    <th>CLIENTE</th>
                    <th>OPCIÓN</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($clientes as $m){ ?>
                <tr>
                    <td class="text-capitalize"><?php echo $m['nombre']; ?></td>
                    <td>
                        <button type="button" class="btn btn-success btn-xs" 
                        onclick="get_data_cliente(<?php echo $m['id_cliente']; ?>,'<?php echo $m['nombre']; ?>');"
                        data-clienteSeleccionado="<?php echo $m['nombre']; ?>"
                        data-dismiss="modal">
                            Seleccionar
                        </button> 
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    <!-- /CONTENIDO -->
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Cancelar</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal Abonos -->
<div class="modal fade" id="abonosModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title text-success" id="exampleModalLabel">Abonar cuenta</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
                    <!-- CONTENIDO -->
        <div class="col-md-3 text-center">
            <!-- FORMAS DE PAGO -->
            <div class="card mx-auto bg-secondary" style="max-width: 20rem;">
                <ul class="list-group list-group-flush text-left">
                    <li class="list-group">
                        <?php foreach ($metodos_pago as $key):  ?>
                            <a id="btnEfectivo" class="text-white list-group-item list-group-item-action btn bg-info text-capitalize" href="#" onclick="return setMetodoPago(<?php echo "'".$key['metodo']."'"; ?>,<?php echo $key['id']; ?>)">
                            <?php echo $key['metodo']; ?>
                            </a>
                        <?php endforeach; ?>
                    </li>                
                </ul>
            </div>
        </div>
        <div class="col-md-9">
            <!-- TOTAL A PAGAR -->
            <div class="row">
                <div class="col-md-12 text-center" id="totalImporte">
                    <!-- IMPORTE TOTAL CART JS-->
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-12 text-center">
                    <span>Seleccione un método de pago</span>
                    <table id="tableMetodo" class="table table-bordered abonos-table">
                        <thead class="bg-light">
                            <tr class="table-active">
                                <th scope="col">Recibido</th>
                                <th scope="col">Importe</th>
                                <th scope="col">Método</th>
                                <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody>                            
                            <!-- INNER HTML JS-->
                        </tbody>
                    </table>
                    <!-- CAMBIO -->
                    <div class="col-md-12 text-center" id="lblCambio">
                        <!-- IMPORTE TOTAL CART JS-->
                    </div>
                </div>
            </div>
        </div>
    <!-- /CONTENIDO -->
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Cancelar</button>
        <button class="btn btn-success" id="btnValidar" onclick="validarPagos();" 
        type="button" data-dismiss="modal">Validar <i class="fas fa-angle-double-right fa-lg"></i></button>
      </div>
    </div>
  </div>
</div>


