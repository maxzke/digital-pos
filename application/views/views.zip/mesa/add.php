<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="page-header">
                <h4 class="page-title">Configurar</h4>
                <ul class="breadcrumbs">
                    <li class="nav-home">
                        <a href="<?php echo base_url('admin'); ?>">
                            <i class="flaticon-home"></i>
                        </a>
                    </li>
                    <li class="separator">
                        <i class="flaticon-right-arrow"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Base</a>
                    </li>
                    <li class="separator">
                        <i class="flaticon-right-arrow"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Panels</a>
                    </li>
                </ul>
            </div>
            <div class="row">
				<div class="col-md-12">
				<!-- CONTENIDO -->
					<?php echo form_open('mesa/add',array("class"=>"form-horizontal")); ?>

						<div class="form-group">
							<label for="seccion" class="col-md-4 control-label"><span class="text-danger">*</span>Piso</label>
							<div class="col-md-8">
								<select name="seccion" class="form-control">
									<option value="" selected="selected">Seleccionar</option>
									<?php 
									foreach($all_seccion as $seccion)
									{
										$selected = ($seccion['id'] == $this->input->post('seccion')) ? ' ' : "";

										echo '<option value="'.$seccion['id'].'" '.$selected.'>'.$seccion['nombre'].'</option>';
									} 
									?>
								</select>
								<span class="text-danger"><?php echo form_error('seccion');?></span>
							</div>
						</div>
						<div class="form-group">
							<label for="cuadrara" class="col-md-4 control-label">Tipo de Mesa</label>
							<div class="col-md-8">
								<select name="cuadrara" class="form-control">
									<option value=""  selected="selected">Seleccionar</option>
									<?php 
									$cuadrara_values = array(
										'1'=>'Cuadrada',
										'0'=>'Redonda',
										'3'=>'Barra',
									);

									foreach($cuadrara_values as $value => $display_text)
									{
										$selected = ($value == $this->input->post('cuadrara')) ? '' : "";

										echo '<option value="'.$value.'" '.$selected.'>'.$display_text.'</option>';
									} 
									?>
								</select>
							</div>
						</div>
						<div class="form-group">
							<label for="nombre" class="col-md-4 control-label"><span class="text-danger">*</span>Nombre</label>
							<div class="col-md-8">
								<input type="text" name="nombre" value="<?php echo $this->input->post('nombre'); ?>" class="form-control" id="nombre" />
								<span class="text-danger"><?php echo form_error('nombre');?></span>
							</div>
						</div>
						<!-- <div class="form-group">
							<label for="arriba" class="col-md-4 control-label">Arriba</label>
							<div class="col-md-8">
								<input type="text" name="arriba" value="<?php //echo $this->input->post('arriba'); ?>" class="form-control" id="arriba" />
							</div>
						</div>
						<div class="form-group">
							<label for="izquierda" class="col-md-4 control-label">Izquierda</label>
							<div class="col-md-8">
								<input type="text" name="izquierda" value="<?php //echo $this->input->post('izquierda'); ?>" class="form-control" id="izquierda" />
							</div>
						</div>
						<div class="form-group">
							<label for="alto" class="col-md-4 control-label">Alto</label>
							<div class="col-md-8">
								<input type="text" name="alto" value="<?php //echo $this->input->post('alto'); ?>" class="form-control" id="alto" />
							</div>
						</div>
						<div class="form-group">
							<label for="ancho" class="col-md-4 control-label">Ancho</label>
							<div class="col-md-8">
								<input type="text" name="ancho" value="<?php //echo $this->input->post('ancho'); ?>" class="form-control" id="ancho" />
							</div>
						</div> -->

						<div class="form-group">
							<div class="col-sm-offset-4 col-sm-8">
								<button type="submit" class="btn btn-success">Guardar</button>
							</div>
						</div>

					<?php echo form_close(); ?>
            	<!-- /CONTENIDO -->
				</div>
            </div>
        </div>
    </div>
</div>