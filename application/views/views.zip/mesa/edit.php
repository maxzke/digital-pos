<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="page-header">
                <h4 class="page-title">Editar Mesa</h4>
                <ul class="breadcrumbs">
                    <li class="nav-home">
                        <a href="<?php echo base_url('mesa'); ?>">
                            <i class="flaticon-home"></i> Volver
                        </a>
                    </li>
                </ul>
            </div>
            <div class="row">
				<div class="col-md-12">
				<!-- CONTENIDO -->
					
					<?php echo form_open('mesa/edit/'.$mesa['id'],array("class"=>"form-horizontal")); ?>

						<div class="form-group">
							<label for="seccion" class="col-md-4 control-label"><span class="text-danger">*</span>Seccion</label>
							<div class="col-md-8">
								<select name="seccion" class="form-control">
									<option value="">select seccion</option>
									<?php 
									foreach($all_seccion as $seccion)
									{
										$selected = ($seccion['id'] == $mesa['seccion']) ? ' selected="selected"' : "";

										echo '<option value="'.$seccion['id'].'" '.$selected.'>'.$seccion['nombre'].'</option>';
									} 
									?>
								</select>
								<span class="text-danger"><?php echo form_error('seccion');?></span>
							</div>
						</div>
						<div class="form-group">
							<label for="cuadrara" class="col-md-4 control-label">Cuadrara</label>
							<div class="col-md-8">
								<select name="cuadrara" class="form-control">
									<option value="">select</option>
									<?php 
									$cuadrara_values = array(
										'1'=>'Cuadrada',
										'0'=>'Redonda',
									);

									foreach($cuadrara_values as $value => $display_text)
									{
										$selected = ($value == $mesa['cuadrara']) ? ' selected="selected"' : "";

										echo '<option value="'.$value.'" '.$selected.'>'.$display_text.'</option>';
									} 
									?>
								</select>
							</div>
						</div>
						<div class="form-group">
							<label for="nombre" class="col-md-4 control-label"><span class="text-danger">*</span>Nombre</label>
							<div class="col-md-8">
								<input type="text" name="nombre" value="<?php echo ($this->input->post('nombre') ? $this->input->post('nombre') : $mesa['nombre']); ?>" class="form-control" id="nombre" />
								<span class="text-danger"><?php echo form_error('nombre');?></span>
							</div>
						</div>
						<div class="form-group" style="display:none;">
							<label for="arriba" class="col-md-4 control-label">Arriba</label>
							<div class="col-md-8">
								<input type="text" name="arriba" value="<?php echo ($this->input->post('arriba') ? $this->input->post('arriba') : $mesa['arriba']); ?>" class="form-control" id="arriba" />
							</div>
						</div>
						<div class="form-group" style="display:none;>
							<label for="izquierda" class="col-md-4 control-label">Izquierda</label>
							<div class="col-md-8">
								<input type="text" name="izquierda" value="<?php echo ($this->input->post('izquierda') ? $this->input->post('izquierda') : $mesa['izquierda']); ?>" class="form-control" id="izquierda" />
							</div>
						</div>
						<div class="form-group" style="display:none;>
							<label for="alto" class="col-md-4 control-label">Alto</label>
							<div class="col-md-8">
								<input type="text" name="alto" value="<?php echo ($this->input->post('alto') ? $this->input->post('alto') : $mesa['alto']); ?>" class="form-control" id="alto" />
							</div>
						</div>
						<div class="form-group" style="display:none;>
							<label for="ancho" class="col-md-4 control-label">Ancho</label>
							<div class="col-md-8">
								<input type="text" name="ancho" value="<?php echo ($this->input->post('ancho') ? $this->input->post('ancho') : $mesa['ancho']); ?>" class="form-control" id="ancho" />
							</div>
						</div>

						<div class="form-group">
							<div class="col-sm-offset-4 col-sm-8">
								<button type="submit" class="btn btn-success">Guardar</button>
							</div>
						</div>

					<?php echo form_close(); ?>
            	<!-- /CONTENIDO -->
				</div>
            </div>
        </div>
    </div>
</div>