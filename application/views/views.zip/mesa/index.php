<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="page-header">
                <h4 class="page-title">Listado de Mesas</h4>
            </div>
            <div class="row">
				<div class="col-md-12">
				<!-- CONTENIDO -->
					<div class="pull-right">
						<a href="<?php echo site_url('mesa/add'); ?>" class="btn btn-success"><i class="fas fa-plus"></i> Nueva Mesa</a> 
						<a href="<?php echo site_url('secciones'); ?>" class="btn btn-primary"><i class="fas fa-plus"></i> Nueva Piso</a> 
						<a href="<?php echo site_url('ajustar-mesas'); ?>" class="btn btn-dark"> <i class="flaticon-expand"></i> Organizar Mesas</a> 
					</div>

					<table id="content-table" class="table table-sm table-striped table-bordered">
							<thead>
								<tr>
									<!-- <th>ID</th> -->
									<th>Piso</th>
									<th>Forma</th>
									<th>Nombre</th>
									<!-- <th>Arriba</th>
									<th>Izquierda</th>
									<th>Alto</th>
									<th>Ancho</th>-->
									<th></th> 
								</tr>
							</thead>
							<tbody>
								<?php foreach($mesas as $m){ ?>
								<tr>
									<!-- <td><?php //echo $m['id']; ?></td> -->
									<td><?php 
											foreach ($all_seccion as $seccion) {
												if ($seccion['id'] == $m['seccion']) {
													echo $seccion['nombre']; 
												}
											}
											?></td>
									<!-- 
										$m['cuadrara']==1 -> Cuadrada
										$m['cuadrara']==0 -> Redonda 
									-->
									<td><?php echo ($m['cuadrara']==1)? "Cuadrada" : "Redonda";; ?></td>
									<td><?php echo $m['nombre']; ?></td>
									<!-- <td><?php //echo $m['arriba']; ?></td>
									<td><?php //echo $m['izquierda']; ?></td>
									<td><?php //echo $m['alto']; ?></td>
									<td><?php //echo $m['ancho']; ?></td> -->
									<td>
										<a href="<?php echo site_url('mesa/edit/'.$m['id']); ?>" class="btn btn-info btn-xs">Editar</a> 
										<a href="<?php echo site_url('mesa/remove/'.$m['id']); ?>" class="btn btn-danger btn-xs">Eliminar</a>
									</td>
								</tr>
								<?php } ?>
							</tbody>
					</table>
            	<!-- /CONTENIDO -->
				</div>
            </div>
        </div>
    </div>
</div>

