<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="page-header">
                <h4 class="page-title">Listado de Usuarios</h4>
            </div>
            <div class="row">
				<div class="col-md-12">
				<!-- CONTENIDO -->					
				<div id="notfound">
					<div class="notfound mt-4">
						<div class="notfound-404">
							<h1>4<span>0</span>1</h1>
						</div>
						<br><br>
						<p class="mt-5">
						No cuentas con permisos necesarios para acceder.
						</p>
						<a href="<?php echo site_url('punto-de-venta'); ?>">volver</a>
					</div>
				</div>
            	<!-- /CONTENIDO -->
				</div>
            </div>
        </div>
    </div>
</div>