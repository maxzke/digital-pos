
<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="row">
				<div class="col-md-12 text-center">
				<!-- CONTENIDO -->
				<div id="notfound">
					<div class="notfound mt-4">
						<div class="notfound-404">
							<h1>4<span>0</span>4</h1>
						</div>
						<br><br>
						<p class="mt-5">
						La página que estas buscando pudo haber sido removida ó esta temporalmente fuera de servicio.
						</p>
						<a href="<?php echo site_url('pos'); ?>">volver</a>
					</div>
				</div>
            	<!-- /CONTENIDO -->
				</div>
            </div>
        </div>
    </div>
</div>